package org.usfirst.frc3853.Pridetronics2018.commands;

import org.usfirst.frc3853.Pridetronics2018.Robot;

import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.command.CommandGroup;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 *
 */
public class SwitchScoringRight extends CommandGroup {

	public SwitchScoringRight() {

		System.out.println("SwitchScoringRight");
		String fms = DriverStation.getInstance().getGameSpecificMessage();
		//addSequential(new WaitShort(10.0));
		// System.out.println("SwitchScoring");
		if (fms.charAt(0) == 'R') {
		// addSequential(new pistonOpen());
		//  SmartDashboard.putString("Scoring right", fms);
		addParallel(new RunLift(), 6.0);
		// addSequential(new DriveForwardDistance(-0.6, 97.0)); // Move 100 inches
		// addSequential(new DriveForwardDistance(0.6, 0.70)); // Stop
		addSequential(new SwitchRight(true));
		}else {
			addSequential(new DriveForwardDistance(0.6, 130));
		}
	}
}
